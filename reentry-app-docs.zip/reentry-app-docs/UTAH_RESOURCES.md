# Utah Community Resources

Local resources the app can connect users to, organized by need. Utah was the first state in the nation to launch a state-level return-to-work program, so there is unusually strong infrastructure to plug into.

**Demo flow for judges:** a user finishing the assessment can be warm-handed directly into Return Utah or Tech-Moms, with Kids in Care covering childcare *during the job hunt itself* — a complete plan → training → childcare → returnship chain, all free to the user.

---

## Return-to-Work Programs (warm-handoff partners)

| Program | What it offers | Link |
|---|---|---|
| **Return Utah** | State-run returnship (launched 2021 by executive order). 16-week paid returnships in state government for Utah residents with a career break of 2+ years, any reason. Includes workshops on resumes, interviewing, job seeking, and LinkedIn. ~70% of participants are women, most returning after raising children. | returnutah.utah.gov |
| **Tech-Moms** | 9-week program helping women gain tech-industry skills and insight; 500+ graduates. Free "Better Way Thursdays" video workshop series (35+ virtual workshops) — linkable directly in-app. Talent Ready Utah "Return to Work" grant recipient. | tech-moms.org |
| **Women Tech Council — AI Ready Returnship (AIR)** | Structured relaunch program (part of Talent Ready Utah) for experienced professionals re-entering an AI-enabled economy. | womentechcouncil.com |
| **UAMMI Returnship** | Return-to-work hiring and mentoring for women in advanced materials/manufacturing. | uammi.org |

## State Workforce Services (free coaching + training money)

| Resource | What it offers | Link |
|---|---|---|
| **Utah Dept. of Workforce Services (DWS)** | The backbone: free one-on-one career coaching; funding for short-term training, certificates, apprenticeships, on-the-job training, and degrees for eligible applicants; resume builder, interview prep, and skill workshops. Walk-in employment centers statewide. | jobs.utah.gov |
| **Talent Ready Utah / Utah Works** | Customized industry training programs tied to employer needs. | business.utah.gov |
| **Apprenticeship Utah** | "Earn and learn" model combining paid on-the-job learning with classroom instruction. | apprenticeship.utah.gov |

## Childcare (the #1 practical barrier)

| Resource | What it offers | Link |
|---|---|---|
| **Utah Child Care Assistance** (DWS Office of Child Care) | Subsidy for working/studying parents up to 85% of state median income; sliding co-pay (some families pay $0); currently no waitlist. Apply via myCase. | jobs.utah.gov/occ · mycase.utah.gov |
| **Kids in Care** | Free drop-in childcare for recently unemployed parents while they job hunt — DWS pays up to 150 hours of job-search childcare. Perfect fit for this app's audience. | jobs.utah.gov |
| **Care About Childcare** | Statewide childcare provider search with provider profiles and quality ratings. | careaboutchildcare.utah.gov |

## General Needs Navigation (Tier-1 directory backbone)

| Resource | What it offers | Link |
|---|---|---|
| **211 Utah (United Way)** | Free, confidential, multilingual referrals for food, housing, utilities, healthcare, transportation, legal help, employment, and childcare. One integration that covers the "life logistics" layer. | 211utah.org · dial 2-1-1 |
| **Family Employment Program (TANF)** | Temporary cash assistance + employment support for qualifying families with children. | jobs.utah.gov |
| **Utah Community Action** | Housing/rental assistance and self-reliance programs for low-income families. | utahca.org |
| **Family Support Centers of Utah** | Parenting support and family stabilization. | utahfamilies.org |
| **Utah Legal Services** | Free civil legal help for low-income Utahns (divorce/custody situations often accompany re-entry). | utahlegalservices.org |

## Worth Vetting (known programs — verify current offerings before integrating)

- **Utah Women & Leadership Project (USU)** — research/data on Utah women's workforce participation; strong source for grant narratives
- **Women's Business Center of Utah** — career and entrepreneurship programming
- **YWCA Utah** — women's empowerment and support services
- **Salt Lake County & local library systems** — free LinkedIn Learning access, resume help, career coaching
- **Community colleges & Utah technical colleges** — short-term certificates; several have participated in tuition-covered re-entry initiatives

---

## Integration Plan by Tier

- **Tier 1 (MVP — curated directory):** hard-code the vetted list above, keyed to user need; assign quarterly link-review ownership
- **Tier 2 (smart matching):** 211 Utah API / findhelp.org integration; match assessment results to DWS training funds, childcare assistance eligibility, and relevant returnships
- **Tier 3 (warm handoffs):** MOUs with Return Utah, Tech-Moms, and returner-friendly employers; "request a connection" button that triggers human follow-up
